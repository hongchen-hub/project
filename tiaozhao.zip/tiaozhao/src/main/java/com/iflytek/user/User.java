package com.iflytek.user;

public class User {

}
